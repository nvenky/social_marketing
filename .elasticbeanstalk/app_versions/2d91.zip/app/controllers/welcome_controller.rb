class WelcomeController < ApplicationController
    def index
       @homepage=true 
    end
end
