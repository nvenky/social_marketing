require 'test_helper'

class AdvertiserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
